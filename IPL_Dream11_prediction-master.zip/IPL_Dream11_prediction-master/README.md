# IPL_Dream11_prediction
This repository contains a model which tries to predict the best team of 11 players which will score the most.


File name

1. "deliveries.csv"
This file contains ball by ball information of the IPL match played between 2008 to 2017


2. "basemodel.csv"
This file contains details of intial six matches. This file was created for the testing of the model.

3. Find_Avg_dr11.py
This file creates csv files (player_name.csv) with average dream11 score of a player


